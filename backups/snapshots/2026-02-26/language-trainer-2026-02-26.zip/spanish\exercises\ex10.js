window.exerciseData = {
    title: "Дієслова в формі yo",
    topicTag: "🧠 ключові дієслова",
    explanation: `
                                            <div class="topic-tag">🧠 Pretérito indefinido (yo)</div>
                                            <h2>Корисні дієслова</h2>
                                            <p>Запам'ятай ці форми, щоб швидко будувати речення про минуле.</p>
                                            <ul>
                                                <li>viv<b>í</b> — я жив</li>
                                                <li>pens<b>é</b> — я думав</li>
                                                <li>entend<b>í</b> — я зрозумів</li>
                                                <li>empec<b>é</b> — я почав</li>
                                                <li>perd<b>í</b> — я загубив</li>
                                                <li>volv<b>í</b> — я повернувся</li>
                                                <li>dorm<b>í</b> — я спав</li>
                                                <li>prefer<b>í</b> — я віддав перевагу</li>
                                            </ul>
                                        `,
    vocab: [
        { ua: "Я жив.", en: "Yo viví." },
        { ua: "Я думав.", en: "Yo pensé." },
        { ua: "Я зрозумів.", en: "Yo entendí." },
        { ua: "Я почав.", en: "Yo empecé." },
        { ua: "Я загубив.", en: "Yo perdí." },
        { ua: "Я повернувся.", en: "Yo volví." },
        { ua: "Я спав.", en: "Yo dormí." },
        { ua: "Я віддав перевагу.", en: "Yo preferí." }
    ],
    sentences: [
        { ua: "Вчора я багато думав про свої плани.", en: "Ayer pensé mucho en mis planes." },
        { ua: "Вчора я загубив мої ключі.", en: "Ayer perdí mis llaves." },
        { ua: "Вчора я дуже добре спав.", en: "Ayer dormí muy bien." }
    ]
};
