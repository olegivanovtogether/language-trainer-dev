window.exerciseData = {
    title: "Практика: приклади речень",
    topicTag: "📝 повні фрази",
    explanation: `
                                            <div class="topic-tag">📝 Повні речення</div>
                                            <h2>Тренування на готових фразах</h2>
                                            <p>Використовуй ці приклади як шаблони для власних історій.</p>
                                        `,
    vocab: [
        { ua: "Вчора я поснідав вдома.", en: "Ayer desayuné en casa." },
        { ua: "Вчора я повечеряв з сім'єю.", en: "Ayer cené con mi familia." },
        { ua: "Вчора я провів день вдома.", en: "Ayer pasé el día en casa." },
        { ua: "Вчора я відвідав свою сім'ю.", en: "Ayer visité a mi familia." },
        { ua: "Я купив новий одяг.", en: "Compré ropa nueva." },
        { ua: "Я подзвонив моєму начальнику вранці.", en: "Llamé a mi jefe por la mañana." },
        { ua: "Вчора я чекав автобус десять хвилин.", en: "Ayer esperé el autobús diez minutos." },
        { ua: "Вчора я закінчив роботу пізно.", en: "Ayer terminé el trabajo tarde." }
    ],
    sentences: [
        { ua: "Я поснідав з другом. Я повечеряв дуже пізно.", en: "Desayuné con un amigo. Cené muy tarde." },
        { ua: "Я провів час з друзями. Я добре провів вихідні.", en: "Pasé tiempo con mis amigos. Pasé un buen fin de semana." },
        { ua: "Я відвідав нову кав'ярню. Я купив подарунок для друга.", en: "Visité una nueva cafetería. Compré un regalo para mi amigo." }
    ]
};
